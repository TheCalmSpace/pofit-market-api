from app.models.eligibility import EligibilityResponse
from app.models.financial_history import FinancialHistoryResponse
from app.models.financials import FinancialsResponse


class EligibilityService:
    """
    Builds the eligibility snapshot required by the POFIT Alpha engine.

    This service DOES NOT decide whether a company is eligible.
    It only extracts the raw values required by AlphaFilterService.
    """

    @staticmethod
    def build(
        quote,
        history: FinancialHistoryResponse,
        financials: FinancialsResponse,
    ) -> EligibilityResponse:

        latest = history.annual[0] if history.annual else None

        market_cap = getattr(quote, "market_cap", None)

        average_daily_value_90d = None

        avg_volume = (
            getattr(quote, "average_volume", None)
            or getattr(quote, "average_volume_3month", None)
            or getattr(quote, "three_month_average_volume", None)
        )

        current_price = (
            getattr(quote, "regular_market_price", None)
            or getattr(quote, "current_price", None)
            or getattr(quote, "price", None)
        )

        if (
            avg_volume is not None
            and current_price is not None
        ):
            average_daily_value_90d = (
                avg_volume * current_price
            )

        revenue = None
        net_income = None
        equity = None

        if latest is not None:
            revenue = latest.revenue
            net_income = latest.net_income
            equity = latest.shareholders_equity

        financials_complete = all(
            value is not None
            for value in (
                market_cap,
                revenue,
                net_income,
                equity,
            )
        )

        return EligibilityResponse(
            market_cap=market_cap,
            average_daily_value_90d=average_daily_value_90d,
            revenue_ttm=revenue,
            net_income_ttm=net_income,
            shareholders_equity=equity,
            financials_complete=financials_complete,
        )