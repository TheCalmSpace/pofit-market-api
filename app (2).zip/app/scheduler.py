from zoneinfo import ZoneInfo

from apscheduler.schedulers.background import BackgroundScheduler

from app.services.daily_top_picks_service import DailyTopPicksService


scheduler = BackgroundScheduler(
    timezone=ZoneInfo("Asia/Kolkata")
)


def generate_india():
    print("=" * 80)
    print("POFIT Scheduler")
    print("Generating India Top Picks...")
    print("=" * 80)

    service = DailyTopPicksService()
    result = service.generate_country("IN")

    print(f"Generated {len(result)} India Top Picks")


def generate_usa():
    print("=" * 80)
    print("POFIT Scheduler")
    print("Generating USA Top Picks...")
    print("=" * 80)

    service = DailyTopPicksService()
    result = service.generate_country("US")

    print(f"Generated {len(result)} USA Top Picks")


def start_scheduler():

    scheduler.add_job(
        generate_india,
        trigger="cron",
        hour=8,
        minute=0,
        id="india_top_picks",
        replace_existing=True,
    )

    scheduler.add_job(
        generate_usa,
        trigger="cron",
        hour=9,
        minute=30,
        id="usa_top_picks",
        replace_existing=True,
    )

    scheduler.start()

    print("=" * 80)
    print("POFIT Scheduler Started")
    print("India  : 08:00 IST")
    print("USA    : 09:30 IST")
    print("=" * 80)